package thaumcraft.api.nodes;

public enum NodeType
{
    NORMAL, UNSTABLE, DARK, TAINTED, HUNGRY, PURE
}